<section id="pageSponsors" class="cmsPage">
  <div class="pageSponsors_sponsorsTable">
      <img src="opt_img/tableUserSponsors2.png" alt="">
  </div>
</section>
