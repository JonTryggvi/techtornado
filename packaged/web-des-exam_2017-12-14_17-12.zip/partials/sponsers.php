<div id="sponsorsModal" class="Sponsers">
  <section class="sponsorsModal">
    <span id="btnCLoseSponsers" class="sponsorsModal__close">
        <svg class="signIn__close__svg" viewBox="0 0 54 53" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
          <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="Style-Guide" transform="translate(-449.000000, -2315.000000)" stroke-width="3" stroke="#2B2B2B">
              <g id="Group-14" transform="translate(119.000000, 2019.000000)">
                <g id="Page-1" transform="translate(8.000000, 109.000000)">
                  <path d="M372.228819,232.546685 L353.858348,213.585778 L372.84009,195.235471 C374.211216,193.910453 374.2474,191.705678 372.920926,190.336057 C371.593682,188.967205 369.386485,188.931061 368.016129,190.256079 L349.034386,208.606386 L330.663915,189.645479 C329.337441,188.275858 327.130244,188.239714 325.759118,189.565501 C324.387992,190.890519 324.351808,193.095293 325.679052,194.464915 L344.048753,213.425822 L325.067011,231.77536 C323.696655,233.101147 323.660471,235.305152 324.986945,236.674773 C326.314189,238.044394 328.520616,238.080538 329.891742,236.754751 L348.873485,218.405213 L367.243956,237.366121 C368.57043,238.734973 370.777627,238.771116 372.148753,237.446098 C373.51911,236.12108 373.555293,233.916306 372.228819,232.546685 Z" id="Stroke-111" class="declineHollowStroke"></path>
                </g>
              </g>
            </g>
          </g>
        </svg>
    </span>
    <div class="sponsorsModal__topInfo">
      <img src="opt_img/icons/svg/diamond.svg" alt="">
      <h2>Our wonderful sponsers!</h2>
      <p>My money's in that office, right? If she start giving me some bullshit about it ain't there, and we got to go someplace else and get it, I'm gonna shoot you in the head then and there. We got to go someplace.</p>
    </div>
    <div class="sponsorsModal__allIcons">
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s1.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s2.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s3.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s4.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s5.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s6.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s7.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s8.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s9.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s10.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s11.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s12.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s13.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s14.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s15.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s16.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s17.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s18.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s19.png" alt="">
      </div>
      <div class="sponsorsModal__allIcons__eachIcon">
        <img src="opt_img/sponsor_logos/s20.png" alt="">
      </div>

    </div>
  </section>
</div>
