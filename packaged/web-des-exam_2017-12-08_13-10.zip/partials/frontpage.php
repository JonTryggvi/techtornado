  <?php include_once('partials/hero.php'); ?>
  <?php include_once('partials/createevent.php'); ?>
  <?php include_once('partials/imageslider.php'); ?>
  <?php include_once('partials/subscribe.php'); ?>
  <?php include_once('partials/footer.php'); ?>
