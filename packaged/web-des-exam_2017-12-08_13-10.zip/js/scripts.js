/*
 2017 Julian Garnier
 Released under the MIT license
*/
var $jscomp$this = this;
(function (u, r) {
  "function" === typeof define && define.amd ? define([], r) : "object" === typeof module && module.exports ? module.exports = r() : u.anime = r();
})(this, function () {
  function u(a) {
    if (!g.col(a)) try {
      return document.querySelectorAll(a);
    } catch (b) {}
  }function r(a) {
    return a.reduce(function (a, c) {
      return a.concat(g.arr(c) ? r(c) : c);
    }, []);
  }function v(a) {
    if (g.arr(a)) return a;g.str(a) && (a = u(a) || a);return a instanceof NodeList || a instanceof HTMLCollection ? [].slice.call(a) : [a];
  }function E(a, b) {
    return a.some(function (a) {
      return a === b;
    });
  }
  function z(a) {
    var b = {},
        c;for (c in a) b[c] = a[c];return b;
  }function F(a, b) {
    var c = z(a),
        d;for (d in a) c[d] = b.hasOwnProperty(d) ? b[d] : a[d];return c;
  }function A(a, b) {
    var c = z(a),
        d;for (d in b) c[d] = g.und(a[d]) ? b[d] : a[d];return c;
  }function R(a) {
    a = a.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, function (a, b, c, h) {
      return b + b + c + c + h + h;
    });var b = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(a);a = parseInt(b[1], 16);var c = parseInt(b[2], 16),
        b = parseInt(b[3], 16);return "rgb(" + a + "," + c + "," + b + ")";
  }function S(a) {
    function b(a, b, c) {
      0 > c && (c += 1);1 < c && --c;return c < 1 / 6 ? a + 6 * (b - a) * c : .5 > c ? b : c < 2 / 3 ? a + (b - a) * (2 / 3 - c) * 6 : a;
    }var c = /hsl\((\d+),\s*([\d.]+)%,\s*([\d.]+)%\)/g.exec(a);a = parseInt(c[1]) / 360;var d = parseInt(c[2]) / 100,
        c = parseInt(c[3]) / 100;if (0 == d) d = c = a = c;else {
      var e = .5 > c ? c * (1 + d) : c + d - c * d,
          k = 2 * c - e,
          d = b(k, e, a + 1 / 3),
          c = b(k, e, a);a = b(k, e, a - 1 / 3);
    }return "rgb(" + 255 * d + "," + 255 * c + "," + 255 * a + ")";
  }function w(a) {
    if (a = /([\+\-]?[0-9#\.]+)(%|px|pt|em|rem|in|cm|mm|ex|pc|vw|vh|deg|rad|turn)?/.exec(a)) return a[2];
  }function T(a) {
    if (-1 < a.indexOf("translate")) return "px";
    if (-1 < a.indexOf("rotate") || -1 < a.indexOf("skew")) return "deg";
  }function G(a, b) {
    return g.fnc(a) ? a(b.target, b.id, b.total) : a;
  }function B(a, b) {
    if (b in a.style) return getComputedStyle(a).getPropertyValue(b.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()) || "0";
  }function H(a, b) {
    if (g.dom(a) && E(U, b)) return "transform";if (g.dom(a) && (a.getAttribute(b) || g.svg(a) && a[b])) return "attribute";if (g.dom(a) && "transform" !== b && B(a, b)) return "css";if (null != a[b]) return "object";
  }function V(a, b) {
    var c = T(b),
        c = -1 < b.indexOf("scale") ? 1 : 0 + c;a = a.style.transform;if (!a) return c;for (var d = [], e = [], k = [], h = /(\w+)\((.+?)\)/g; d = h.exec(a);) e.push(d[1]), k.push(d[2]);a = k.filter(function (a, c) {
      return e[c] === b;
    });return a.length ? a[0] : c;
  }function I(a, b) {
    switch (H(a, b)) {case "transform":
        return V(a, b);case "css":
        return B(a, b);case "attribute":
        return a.getAttribute(b);}return a[b] || 0;
  }function J(a, b) {
    var c = /^(\*=|\+=|-=)/.exec(a);if (!c) return a;b = parseFloat(b);a = parseFloat(a.replace(c[0], ""));switch (c[0][0]) {case "+":
        return b + a;case "-":
        return b - a;case "*":
        return b * a;}
  }function C(a) {
    return g.obj(a) && a.hasOwnProperty("totalLength");
  }function W(a, b) {
    function c(c) {
      c = void 0 === c ? 0 : c;return a.el.getPointAtLength(1 <= b + c ? b + c : 0);
    }var d = c(),
        e = c(-1),
        k = c(1);switch (a.property) {case "x":
        return d.x;case "y":
        return d.y;case "angle":
        return 180 * Math.atan2(k.y - e.y, k.x - e.x) / Math.PI;}
  }function K(a, b) {
    var c = /-?\d*\.?\d+/g;a = C(a) ? a.totalLength : a;if (g.col(a)) b = g.rgb(a) ? a : g.hex(a) ? R(a) : g.hsl(a) ? S(a) : void 0;else {
      var d = w(a);a = d ? a.substr(0, a.length - d.length) : a;b = b ? a + b : a;
    }b += "";return { original: b,
      numbers: b.match(c) ? b.match(c).map(Number) : [0], strings: b.split(c) };
  }function X(a, b) {
    return b.reduce(function (b, d, e) {
      return b + a[e - 1] + d;
    });
  }function L(a) {
    return (a ? r(g.arr(a) ? a.map(v) : v(a)) : []).filter(function (a, c, d) {
      return d.indexOf(a) === c;
    });
  }function Y(a) {
    var b = L(a);return b.map(function (a, d) {
      return { target: a, id: d, total: b.length };
    });
  }function Z(a, b) {
    var c = z(b);if (g.arr(a)) {
      var d = a.length;2 !== d || g.obj(a[0]) ? g.fnc(b.duration) || (c.duration = b.duration / d) : a = { value: a };
    }return v(a).map(function (a, c) {
      c = c ? 0 : b.delay;
      a = g.obj(a) && !C(a) ? a : { value: a };g.und(a.delay) && (a.delay = c);return a;
    }).map(function (a) {
      return A(a, c);
    });
  }function aa(a, b) {
    var c = {},
        d;for (d in a) {
      var e = G(a[d], b);g.arr(e) && (e = e.map(function (a) {
        return G(a, b);
      }), 1 === e.length && (e = e[0]));c[d] = e;
    }c.duration = parseFloat(c.duration);c.delay = parseFloat(c.delay);return c;
  }function ba(a) {
    return g.arr(a) ? x.apply(this, a) : M[a];
  }function ca(a, b) {
    var c;return a.tweens.map(function (d) {
      d = aa(d, b);var e = d.value,
          k = I(b.target, a.name),
          h = c ? c.to.original : k,
          h = g.arr(e) ? e[0] : h,
          n = J(g.arr(e) ? e[1] : e, h),
          k = w(n) || w(h) || w(k);d.isPath = C(e);d.from = K(h, k);d.to = K(n, k);d.start = c ? c.end : a.offset;d.end = d.start + d.delay + d.duration;d.easing = ba(d.easing);d.elasticity = (1E3 - Math.min(Math.max(d.elasticity, 1), 999)) / 1E3;g.col(d.from.original) && (d.round = 1);return c = d;
    });
  }function da(a, b) {
    return r(a.map(function (a) {
      return b.map(function (b) {
        var c = H(a.target, b.name);if (c) {
          var d = ca(b, a);b = { type: c, property: b.name, animatable: a, tweens: d, duration: d[d.length - 1].end, delay: d[0].delay };
        } else b = void 0;return b;
      });
    })).filter(function (a) {
      return !g.und(a);
    });
  }
  function N(a, b, c) {
    var d = "delay" === a ? Math.min : Math.max;return b.length ? d.apply(Math, b.map(function (b) {
      return b[a];
    })) : c[a];
  }function ea(a) {
    var b = F(fa, a),
        c = F(ga, a),
        d = Y(a.targets),
        e = [],
        g = A(b, c),
        h;for (h in a) g.hasOwnProperty(h) || "targets" === h || e.push({ name: h, offset: g.offset, tweens: Z(a[h], c) });a = da(d, e);return A(b, { animatables: d, animations: a, duration: N("duration", a, c), delay: N("delay", a, c) });
  }function m(a) {
    function b() {
      return window.Promise && new Promise(function (a) {
        return P = a;
      });
    }function c(a) {
      return f.reversed ? f.duration - a : a;
    }function d(a) {
      for (var b = 0, c = {}, d = f.animations, e = {}; b < d.length;) {
        var g = d[b],
            h = g.animatable,
            n = g.tweens;e.tween = n.filter(function (b) {
          return a < b.end;
        })[0] || n[n.length - 1];e.isPath$0 = e.tween.isPath;e.round = e.tween.round;e.eased = e.tween.easing(Math.min(Math.max(a - e.tween.start - e.tween.delay, 0), e.tween.duration) / e.tween.duration, e.tween.elasticity);n = X(e.tween.to.numbers.map(function (a) {
          return function (b, c) {
            c = a.isPath$0 ? 0 : a.tween.from.numbers[c];b = c + a.eased * (b - c);a.isPath$0 && (b = W(a.tween.value, b));a.round && (b = Math.round(b * a.round) / a.round);return b;
          };
        }(e)), e.tween.to.strings);ha[g.type](h.target, g.property, n, c, h.id);g.currentValue = n;b++;e = { isPath$0: e.isPath$0, tween: e.tween, eased: e.eased, round: e.round };
      }if (c) for (var k in c) D || (D = B(document.body, "transform") ? "transform" : "-webkit-transform"), f.animatables[k].target.style[D] = c[k].join(" ");f.currentTime = a;f.progress = a / f.duration * 100;
    }function e(a) {
      if (f[a]) f[a](f);
    }function g() {
      f.remaining && !0 !== f.remaining && f.remaining--;
    }function h(a) {
      var h = f.duration,
          k = f.offset,
          m = f.delay,
          O = f.currentTime,
          p = f.reversed,
          q = c(a),
          q = Math.min(Math.max(q, 0), h);q > k && q < h ? (d(q), !f.began && q >= m && (f.began = !0, e("begin")), e("run")) : (q <= k && 0 !== O && (d(0), p && g()), q >= h && O !== h && (d(h), p || g()));a >= h && (f.remaining ? (t = n, "alternate" === f.direction && (f.reversed = !f.reversed)) : (f.pause(), P(), Q = b(), f.completed || (f.completed = !0, e("complete"))), l = 0);if (f.children) for (a = f.children, h = 0; h < a.length; h++) a[h].seek(q);e("update");
    }a = void 0 === a ? {} : a;var n,
        t,
        l = 0,
        P = null,
        Q = b(),
        f = ea(a);f.reset = function () {
      var a = f.direction,
          b = f.loop;f.currentTime = 0;f.progress = 0;f.paused = !0;f.began = !1;f.completed = !1;f.reversed = "reverse" === a;f.remaining = "alternate" === a && 1 === b ? 2 : b;
    };f.tick = function (a) {
      n = a;t || (t = n);h((l + n - t) * m.speed);
    };f.seek = function (a) {
      h(c(a));
    };f.pause = function () {
      var a = p.indexOf(f);-1 < a && p.splice(a, 1);f.paused = !0;
    };f.play = function () {
      f.paused && (f.paused = !1, t = 0, l = f.completed ? 0 : c(f.currentTime), p.push(f), y || ia());
    };f.reverse = function () {
      f.reversed = !f.reversed;t = 0;l = c(f.currentTime);
    };f.restart = function () {
      f.pause();
      f.reset();f.play();
    };f.finished = Q;f.reset();f.autoplay && f.play();return f;
  }var fa = { update: void 0, begin: void 0, run: void 0, complete: void 0, loop: 1, direction: "normal", autoplay: !0, offset: 0 },
      ga = { duration: 1E3, delay: 0, easing: "easeOutElastic", elasticity: 500, round: 0 },
      U = "translateX translateY translateZ rotate rotateX rotateY rotateZ scale scaleX scaleY scaleZ skewX skewY".split(" "),
      D,
      g = { arr: function (a) {
      return Array.isArray(a);
    }, obj: function (a) {
      return -1 < Object.prototype.toString.call(a).indexOf("Object");
    }, svg: function (a) {
      return a instanceof SVGElement;
    }, dom: function (a) {
      return a.nodeType || g.svg(a);
    }, str: function (a) {
      return "string" === typeof a;
    }, fnc: function (a) {
      return "function" === typeof a;
    }, und: function (a) {
      return "undefined" === typeof a;
    }, hex: function (a) {
      return (/(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(a)
      );
    }, rgb: function (a) {
      return (/^rgb/.test(a)
      );
    }, hsl: function (a) {
      return (/^hsl/.test(a)
      );
    }, col: function (a) {
      return g.hex(a) || g.rgb(a) || g.hsl(a);
    } },
      x = function () {
    function a(a, c, d) {
      return (((1 - 3 * d + 3 * c) * a + (3 * d - 6 * c)) * a + 3 * c) * a;
    }return function (b, c, d, e) {
      if (0 <= b && 1 >= b && 0 <= d && 1 >= d) {
        var g = new Float32Array(11);if (b !== c || d !== e) for (var h = 0; 11 > h; ++h) g[h] = a(.1 * h, b, d);return function (h) {
          if (b === c && d === e) return h;if (0 === h) return 0;if (1 === h) return 1;for (var k = 0, l = 1; 10 !== l && g[l] <= h; ++l) k += .1;--l;var l = k + (h - g[l]) / (g[l + 1] - g[l]) * .1,
              n = 3 * (1 - 3 * d + 3 * b) * l * l + 2 * (3 * d - 6 * b) * l + 3 * b;if (.001 <= n) {
            for (k = 0; 4 > k; ++k) {
              n = 3 * (1 - 3 * d + 3 * b) * l * l + 2 * (3 * d - 6 * b) * l + 3 * b;if (0 === n) break;var m = a(l, b, d) - h,
                  l = l - m / n;
            }h = l;
          } else if (0 === n) h = l;else {
            var l = k,
                k = k + .1,
                f = 0;do m = l + (k - l) / 2, n = a(m, b, d) - h, 0 < n ? k = m : l = m; while (1e-7 < Math.abs(n) && 10 > ++f);h = m;
          }return a(h, c, e);
        };
      }
    };
  }(),
      M = function () {
    function a(a, b) {
      return 0 === a || 1 === a ? a : -Math.pow(2, 10 * (a - 1)) * Math.sin(2 * (a - 1 - b / (2 * Math.PI) * Math.asin(1)) * Math.PI / b);
    }var b = "Quad Cubic Quart Quint Sine Expo Circ Back Elastic".split(" "),
        c = { In: [[.55, .085, .68, .53], [.55, .055, .675, .19], [.895, .03, .685, .22], [.755, .05, .855, .06], [.47, 0, .745, .715], [.95, .05, .795, .035], [.6, .04, .98, .335], [.6, -.28, .735, .045], a], Out: [[.25, .46, .45, .94], [.215, .61, .355, 1], [.165, .84, .44, 1], [.23, 1, .32, 1], [.39, .575, .565, 1], [.19, 1, .22, 1], [.075, .82, .165, 1], [.175, .885, .32, 1.275], function (b, c) {
        return 1 - a(1 - b, c);
      }], InOut: [[.455, .03, .515, .955], [.645, .045, .355, 1], [.77, 0, .175, 1], [.86, 0, .07, 1], [.445, .05, .55, .95], [1, 0, 0, 1], [.785, .135, .15, .86], [.68, -.55, .265, 1.55], function (b, c) {
        return .5 > b ? a(2 * b, c) / 2 : 1 - a(-2 * b + 2, c) / 2;
      }] },
        d = { linear: x(.25, .25, .75, .75) },
        e = {},
        k;for (k in c) e.type = k, c[e.type].forEach(function (a) {
      return function (c, e) {
        d["ease" + a.type + b[e]] = g.fnc(c) ? c : x.apply($jscomp$this, c);
      };
    }(e)), e = { type: e.type };return d;
  }(),
      ha = { css: function (a, b, c) {
      return a.style[b] = c;
    }, attribute: function (a, b, c) {
      return a.setAttribute(b, c);
    }, object: function (a, b, c) {
      return a[b] = c;
    }, transform: function (a, b, c, d, e) {
      d[e] || (d[e] = []);d[e].push(b + "(" + c + ")");
    } },
      p = [],
      y = 0,
      ia = function () {
    function a() {
      y = requestAnimationFrame(b);
    }function b(b) {
      var c = p.length;if (c) {
        for (var e = 0; e < c;) p[e] && p[e].tick(b), e++;a();
      } else cancelAnimationFrame(y), y = 0;
    }return a;
  }();m.version = "2.0.1";m.speed = 1;m.running = p;m.remove = function (a) {
    a = L(a);for (var b = p.length - 1; 0 <= b; b--) for (var c = p[b], d = c.animations, e = d.length - 1; 0 <= e; e--) E(a, d[e].animatable.target) && (d.splice(e, 1), d.length || c.pause());
  };m.getValue = I;m.path = function (a, b) {
    var c = g.str(a) ? u(a)[0] : a,
        d = b || 100;return function (a) {
      return { el: c, property: a, totalLength: c.getTotalLength() * (d / 100) };
    };
  };m.setDashoffset = function (a) {
    var b = a.getTotalLength();a.setAttribute("stroke-dasharray", b);return b;
  };m.bezier = x;m.easings = M;m.timeline = function (a) {
    var b = m(a);b.duration = 0;b.children = [];b.add = function (a) {
      v(a).forEach(function (a) {
        var c = a.offset,
            d = b.duration;a.autoplay = !1;a.offset = g.und(c) ? d : J(c, d);a = m(a);a.duration > d && (b.duration = a.duration);b.children.push(a);
      });return b;
    };return b;
  };m.random = function (a, b) {
    return Math.floor(Math.random() * (b - a + 1)) + a;
  };return m;
});
;/**
 * main.js
 * http://www.codrops.com
 *
 * Licensed under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 *
 * Copyright 2017, Codrops
 * http://www.codrops.com
 */
{
	class ImgbtnFloater {
		constructor(el) {
			this.DOM = {};
			this.DOM.el = el;
			this.DOM.svg = this.DOM.el.querySelector('.btnFloater__svg');
			this.DOM.path = this.DOM.svg.querySelector('path');
			this.paths = {};
			this.paths.start = this.DOM.path.getAttribute('d');
			this.paths.end = this.DOM.el.dataset.morphPath;
			this.DOM.deco = this.DOM.svg.querySelector('.btnFloater__deco');
			this.DOM.image = this.DOM.svg.querySelector('image');
			// this.DOM.title = this.DOM.el.querySelector('.btnFloater__meta > .btnFloater__title');
			// this.DOM.subtitle = this.DOM.el.querySelector('.btnFloater__meta > .btnFloater__subtitle');
			this.CONFIG = {
				// Defaults:
				animation: {
					path: {
						duration: this.DOM.el.dataset.animationPathDuration || 1500,
						delay: this.DOM.el.dataset.animationPathDelay || 0,
						easing: this.DOM.el.dataset.animationPathEasing || 'easeOutElastic',
						elasticity: this.DOM.el.dataset.pathElasticity || 400,
						scaleX: this.DOM.el.dataset.pathScalex || 1,
						scaleY: this.DOM.el.dataset.pathScaley || 1,
						translateX: this.DOM.el.dataset.pathTranslatex || 0,
						translateY: this.DOM.el.dataset.pathTranslatey || 0,
						rotate: this.DOM.el.dataset.pathRotate || 0
					},
					image: {
						duration: this.DOM.el.dataset.animationImageDuration || 2000,
						delay: this.DOM.el.dataset.animationImageDelay || 0,
						easing: this.DOM.el.dataset.animationImageEasing || 'easeOutElastic',
						elasticity: this.DOM.el.dataset.imageElasticity || 400,
						scaleX: this.DOM.el.dataset.imageScalex || 1.1,
						scaleY: this.DOM.el.dataset.imageScaley || 1.1,
						translateX: this.DOM.el.dataset.imageTranslatex || 0,
						translateY: this.DOM.el.dataset.imageTranslatey || 0,
						rotate: this.DOM.el.dataset.imageRotate || 0
					},
					deco: {
						duration: this.DOM.el.dataset.animationDecoDuration || 2500,
						delay: this.DOM.el.dataset.animationDecoDelay || 0,
						easing: this.DOM.el.dataset.animationDecoEasing || 'easeOutQuad',
						elasticity: this.DOM.el.dataset.decoElasticity || 400,
						scaleX: this.DOM.el.dataset.decoScalex || 0.9,
						scaleY: this.DOM.el.dataset.decoScaley || 0.9,
						translateX: this.DOM.el.dataset.decoTranslatex || 0,
						translateY: this.DOM.el.dataset.decoTranslatey || 0,
						rotate: this.DOM.el.dataset.decoRotate || 0
					}
				}
			};
			this.initEvents();
		}
		initEvents() {
			this.mouseenterFn = () => {
				this.mouseTimeout = setTimeout(() => {
					this.isActive = true;
					this.animate();
				}, 75);
			};
			this.mouseleaveFn = () => {
				clearTimeout(this.mouseTimeout);
				if (this.isActive) {
					this.isActive = false;
					this.animate();
				}
			};
			this.DOM.el.addEventListener('mouseenter', this.mouseenterFn);
			this.DOM.el.addEventListener('mouseleave', this.mouseleaveFn);
			this.DOM.el.addEventListener('touchstart', this.mouseenterFn);
			this.DOM.el.addEventListener('touchend', this.mouseleaveFn);
		}
		getAnimeObj(targetStr) {
			const target = this.DOM[targetStr];
			let animeOpts = {
				targets: target,
				duration: this.CONFIG.animation[targetStr].duration,
				delay: this.CONFIG.animation[targetStr].delay,
				easing: this.CONFIG.animation[targetStr].easing,
				elasticity: this.CONFIG.animation[targetStr].elasticity,
				scaleX: this.isActive ? this.CONFIG.animation[targetStr].scaleX : 1,
				scaleY: this.isActive ? this.CONFIG.animation[targetStr].scaleY : 1,
				translateX: this.isActive ? this.CONFIG.animation[targetStr].translateX : 0,
				translateY: this.isActive ? this.CONFIG.animation[targetStr].translateY : 0,
				rotate: this.isActive ? this.CONFIG.animation[targetStr].rotate : 0
			};
			if (targetStr === 'path') {
				animeOpts.d = this.isActive ? this.paths.end : this.paths.start;
			}
			anime.remove(target);
			return animeOpts;
		}
		animate() {
			// Animate the path, the image and deco.
			anime(this.getAnimeObj('path'));
			anime(this.getAnimeObj('image'));
			anime(this.getAnimeObj('deco'));
			// Title and Subtitle animation
			anime.remove(this.DOM.title);
			anime({
				targets: this.DOM.title,
				easing: 'easeOutQuad',
				translateY: this.isActive ? [{ value: '-50%', duration: 200 }, { value: ['50%', '0%'], duration: 200 }] : [{ value: '50%', duration: 200 }, { value: ['-50%', '0%'], duration: 200 }],
				opacity: [{ value: 0, duration: 200 }, { value: 1, duration: 200 }]
			});
			anime.remove(this.DOM.subtitle);
			anime({
				targets: this.DOM.subtitle,
				easing: 'easeOutQuad',
				translateY: this.isActive ? { value: ['50%', '0%'], duration: 200, delay: 250 } : { value: '0%', duration: 1 },
				opacity: this.isActive ? { value: [0, 1], duration: 200, delay: 250 } : { value: 0, duration: 1 }
			});
		}
	}

	const btnFloater = Array.from(document.querySelectorAll('.btnFloater'));
	const init = (() => btnFloater.forEach(btnFloater => new ImgbtnFloater(btnFloater)))();
	setTimeout(() => document.body.classList.remove('loading'), 2000);
};
;/*! Hammer.JS - v2.0.8 - 2016-04-23
 * http://hammerjs.github.io/
 *
 * Copyright (c) 2016 Jorik Tangelder;
 * Licensed under the MIT license */
!function (a, b, c, d) {
  "use strict";

  function e(a, b, c) {
    return setTimeout(j(a, c), b);
  }

  function f(a, b, c) {
    return Array.isArray(a) ? (g(a, c[b], c), !0) : !1;
  }

  function g(a, b, c) {
    var e;
    if (a) if (a.forEach) a.forEach(b, c);else if (a.length !== d) for (e = 0; e < a.length;) b.call(c, a[e], e, a), e++;else for (e in a) a.hasOwnProperty(e) && b.call(c, a[e], e, a);
  }

  function h(b, c, d) {
    var e = "DEPRECATED METHOD: " + c + "\n" + d + " AT \n";
    return function () {
      var c = new Error("get-stack-trace"),
          d = c && c.stack ? c.stack.replace(/^[^\(]+?[\n$]/gm, "").replace(/^\s+at\s+/gm, "").replace(/^Object.<anonymous>\s*\(/gm, "{anonymous}()@") : "Unknown Stack Trace",
          f = a.console && (a.console.warn || a.console.log);
      return f && f.call(a.console, e, d), b.apply(this, arguments);
    };
  }

  function i(a, b, c) {
    var d,
        e = b.prototype;
    d = a.prototype = Object.create(e), d.constructor = a, d._super = e, c && la(d, c);
  }

  function j(a, b) {
    return function () {
      return a.apply(b, arguments);
    };
  }

  function k(a, b) {
    return typeof a == oa ? a.apply(b ? b[0] || d : d, b) : a;
  }

  function l(a, b) {
    return a === d ? b : a;
  }

  function m(a, b, c) {
    g(q(b), function (b) {
      a.addEventListener(b, c, !1);
    });
  }

  function n(a, b, c) {
    g(q(b), function (b) {
      a.removeEventListener(b, c, !1);
    });
  }

  function o(a, b) {
    for (; a;) {
      if (a == b) return !0;
      a = a.parentNode;
    }
    return !1;
  }

  function p(a, b) {
    return a.indexOf(b) > -1;
  }

  function q(a) {
    return a.trim().split(/\s+/g);
  }

  function r(a, b, c) {
    if (a.indexOf && !c) return a.indexOf(b);
    for (var d = 0; d < a.length;) {
      if (c && a[d][c] == b || !c && a[d] === b) return d;
      d++;
    }
    return -1;
  }

  function s(a) {
    return Array.prototype.slice.call(a, 0);
  }

  function t(a, b, c) {
    for (var d = [], e = [], f = 0; f < a.length;) {
      var g = b ? a[f][b] : a[f];
      r(e, g) < 0 && d.push(a[f]), e[f] = g, f++;
    }
    return c && (d = b ? d.sort(function (a, c) {
      return a[b] > c[b];
    }) : d.sort()), d;
  }

  function u(a, b) {
    for (var c, e, f = b[0].toUpperCase() + b.slice(1), g = 0; g < ma.length;) {
      if (c = ma[g], e = c ? c + f : b, e in a) return e;
      g++;
    }
    return d;
  }

  function v() {
    return ua++;
  }

  function w(b) {
    var c = b.ownerDocument || b;
    return c.defaultView || c.parentWindow || a;
  }

  function x(a, b) {
    var c = this;
    this.manager = a, this.callback = b, this.element = a.element, this.target = a.options.inputTarget, this.domHandler = function (b) {
      k(a.options.enable, [a]) && c.handler(b);
    }, this.init();
  }

  function y(a) {
    var b,
        c = a.options.inputClass;
    return new (b = c ? c : xa ? M : ya ? P : wa ? R : L)(a, z);
  }

  function z(a, b, c) {
    var d = c.pointers.length,
        e = c.changedPointers.length,
        f = b & Ea && d - e === 0,
        g = b & (Ga | Ha) && d - e === 0;
    c.isFirst = !!f, c.isFinal = !!g, f && (a.session = {}), c.eventType = b, A(a, c), a.emit("hammer.input", c), a.recognize(c), a.session.prevInput = c;
  }

  function A(a, b) {
    var c = a.session,
        d = b.pointers,
        e = d.length;
    c.firstInput || (c.firstInput = D(b)), e > 1 && !c.firstMultiple ? c.firstMultiple = D(b) : 1 === e && (c.firstMultiple = !1);
    var f = c.firstInput,
        g = c.firstMultiple,
        h = g ? g.center : f.center,
        i = b.center = E(d);
    b.timeStamp = ra(), b.deltaTime = b.timeStamp - f.timeStamp, b.angle = I(h, i), b.distance = H(h, i), B(c, b), b.offsetDirection = G(b.deltaX, b.deltaY);
    var j = F(b.deltaTime, b.deltaX, b.deltaY);
    b.overallVelocityX = j.x, b.overallVelocityY = j.y, b.overallVelocity = qa(j.x) > qa(j.y) ? j.x : j.y, b.scale = g ? K(g.pointers, d) : 1, b.rotation = g ? J(g.pointers, d) : 0, b.maxPointers = c.prevInput ? b.pointers.length > c.prevInput.maxPointers ? b.pointers.length : c.prevInput.maxPointers : b.pointers.length, C(c, b);
    var k = a.element;
    o(b.srcEvent.target, k) && (k = b.srcEvent.target), b.target = k;
  }

  function B(a, b) {
    var c = b.center,
        d = a.offsetDelta || {},
        e = a.prevDelta || {},
        f = a.prevInput || {};
    b.eventType !== Ea && f.eventType !== Ga || (e = a.prevDelta = {
      x: f.deltaX || 0,
      y: f.deltaY || 0
    }, d = a.offsetDelta = {
      x: c.x,
      y: c.y
    }), b.deltaX = e.x + (c.x - d.x), b.deltaY = e.y + (c.y - d.y);
  }

  function C(a, b) {
    var c,
        e,
        f,
        g,
        h = a.lastInterval || b,
        i = b.timeStamp - h.timeStamp;
    if (b.eventType != Ha && (i > Da || h.velocity === d)) {
      var j = b.deltaX - h.deltaX,
          k = b.deltaY - h.deltaY,
          l = F(i, j, k);
      e = l.x, f = l.y, c = qa(l.x) > qa(l.y) ? l.x : l.y, g = G(j, k), a.lastInterval = b;
    } else c = h.velocity, e = h.velocityX, f = h.velocityY, g = h.direction;
    b.velocity = c, b.velocityX = e, b.velocityY = f, b.direction = g;
  }

  function D(a) {
    for (var b = [], c = 0; c < a.pointers.length;) b[c] = {
      clientX: pa(a.pointers[c].clientX),
      clientY: pa(a.pointers[c].clientY)
    }, c++;
    return {
      timeStamp: ra(),
      pointers: b,
      center: E(b),
      deltaX: a.deltaX,
      deltaY: a.deltaY
    };
  }

  function E(a) {
    var b = a.length;
    if (1 === b) return {
      x: pa(a[0].clientX),
      y: pa(a[0].clientY)
    };
    for (var c = 0, d = 0, e = 0; b > e;) c += a[e].clientX, d += a[e].clientY, e++;
    return {
      x: pa(c / b),
      y: pa(d / b)
    };
  }

  function F(a, b, c) {
    return {
      x: b / a || 0,
      y: c / a || 0
    };
  }

  function G(a, b) {
    return a === b ? Ia : qa(a) >= qa(b) ? 0 > a ? Ja : Ka : 0 > b ? La : Ma;
  }

  function H(a, b, c) {
    c || (c = Qa);
    var d = b[c[0]] - a[c[0]],
        e = b[c[1]] - a[c[1]];
    return Math.sqrt(d * d + e * e);
  }

  function I(a, b, c) {
    c || (c = Qa);
    var d = b[c[0]] - a[c[0]],
        e = b[c[1]] - a[c[1]];
    return 180 * Math.atan2(e, d) / Math.PI;
  }

  function J(a, b) {
    return I(b[1], b[0], Ra) + I(a[1], a[0], Ra);
  }

  function K(a, b) {
    return H(b[0], b[1], Ra) / H(a[0], a[1], Ra);
  }

  function L() {
    this.evEl = Ta, this.evWin = Ua, this.pressed = !1, x.apply(this, arguments);
  }

  function M() {
    this.evEl = Xa, this.evWin = Ya, x.apply(this, arguments), this.store = this.manager.session.pointerEvents = [];
  }

  function N() {
    this.evTarget = $a, this.evWin = _a, this.started = !1, x.apply(this, arguments);
  }

  function O(a, b) {
    var c = s(a.touches),
        d = s(a.changedTouches);
    return b & (Ga | Ha) && (c = t(c.concat(d), "identifier", !0)), [c, d];
  }

  function P() {
    this.evTarget = bb, this.targetIds = {}, x.apply(this, arguments);
  }

  function Q(a, b) {
    var c = s(a.touches),
        d = this.targetIds;
    if (b & (Ea | Fa) && 1 === c.length) return d[c[0].identifier] = !0, [c, c];
    var e,
        f,
        g = s(a.changedTouches),
        h = [],
        i = this.target;
    if (f = c.filter(function (a) {
      return o(a.target, i);
    }), b === Ea) for (e = 0; e < f.length;) d[f[e].identifier] = !0, e++;
    for (e = 0; e < g.length;) d[g[e].identifier] && h.push(g[e]), b & (Ga | Ha) && delete d[g[e].identifier], e++;
    return h.length ? [t(f.concat(h), "identifier", !0), h] : void 0;
  }

  function R() {
    x.apply(this, arguments);
    var a = j(this.handler, this);
    this.touch = new P(this.manager, a), this.mouse = new L(this.manager, a), this.primaryTouch = null, this.lastTouches = [];
  }

  function S(a, b) {
    a & Ea ? (this.primaryTouch = b.changedPointers[0].identifier, T.call(this, b)) : a & (Ga | Ha) && T.call(this, b);
  }

  function T(a) {
    var b = a.changedPointers[0];
    if (b.identifier === this.primaryTouch) {
      var c = {
        x: b.clientX,
        y: b.clientY
      };
      this.lastTouches.push(c);
      var d = this.lastTouches,
          e = function () {
        var a = d.indexOf(c);
        a > -1 && d.splice(a, 1);
      };
      setTimeout(e, cb);
    }
  }

  function U(a) {
    for (var b = a.srcEvent.clientX, c = a.srcEvent.clientY, d = 0; d < this.lastTouches.length; d++) {
      var e = this.lastTouches[d],
          f = Math.abs(b - e.x),
          g = Math.abs(c - e.y);
      if (db >= f && db >= g) return !0;
    }
    return !1;
  }

  function V(a, b) {
    this.manager = a, this.set(b);
  }

  function W(a) {
    if (p(a, jb)) return jb;
    var b = p(a, kb),
        c = p(a, lb);
    return b && c ? jb : b || c ? b ? kb : lb : p(a, ib) ? ib : hb;
  }

  function X() {
    if (!fb) return !1;
    var b = {},
        c = a.CSS && a.CSS.supports;
    return ["auto", "manipulation", "pan-y", "pan-x", "pan-x pan-y", "none"].forEach(function (d) {
      b[d] = c ? a.CSS.supports("touch-action", d) : !0;
    }), b;
  }

  function Y(a) {
    this.options = la({}, this.defaults, a || {}), this.id = v(), this.manager = null, this.options.enable = l(this.options.enable, !0), this.state = nb, this.simultaneous = {}, this.requireFail = [];
  }

  function Z(a) {
    return a & sb ? "cancel" : a & qb ? "end" : a & pb ? "move" : a & ob ? "start" : "";
  }

  function $(a) {
    return a == Ma ? "down" : a == La ? "up" : a == Ja ? "left" : a == Ka ? "right" : "";
  }

  function _(a, b) {
    var c = b.manager;
    return c ? c.get(a) : a;
  }

  function aa() {
    Y.apply(this, arguments);
  }

  function ba() {
    aa.apply(this, arguments), this.pX = null, this.pY = null;
  }

  function ca() {
    aa.apply(this, arguments);
  }

  function da() {
    Y.apply(this, arguments), this._timer = null, this._input = null;
  }

  function ea() {
    aa.apply(this, arguments);
  }

  function fa() {
    aa.apply(this, arguments);
  }

  function ga() {
    Y.apply(this, arguments), this.pTime = !1, this.pCenter = !1, this._timer = null, this._input = null, this.count = 0;
  }

  function ha(a, b) {
    return b = b || {}, b.recognizers = l(b.recognizers, ha.defaults.preset), new ia(a, b);
  }

  function ia(a, b) {
    this.options = la({}, ha.defaults, b || {}), this.options.inputTarget = this.options.inputTarget || a, this.handlers = {}, this.session = {}, this.recognizers = [], this.oldCssProps = {}, this.element = a, this.input = y(this), this.touchAction = new V(this, this.options.touchAction), ja(this, !0), g(this.options.recognizers, function (a) {
      var b = this.add(new a[0](a[1]));
      a[2] && b.recognizeWith(a[2]), a[3] && b.requireFailure(a[3]);
    }, this);
  }

  function ja(a, b) {
    var c = a.element;
    if (c.style) {
      var d;
      g(a.options.cssProps, function (e, f) {
        d = u(c.style, f), b ? (a.oldCssProps[d] = c.style[d], c.style[d] = e) : c.style[d] = a.oldCssProps[d] || "";
      }), b || (a.oldCssProps = {});
    }
  }

  function ka(a, c) {
    var d = b.createEvent("Event");
    d.initEvent(a, !0, !0), d.gesture = c, c.target.dispatchEvent(d);
  }
  var la,
      ma = ["", "webkit", "Moz", "MS", "ms", "o"],
      na = b.createElement("div"),
      oa = "function",
      pa = Math.round,
      qa = Math.abs,
      ra = Date.now;
  la = "function" != typeof Object.assign ? function (a) {
    if (a === d || null === a) throw new TypeError("Cannot convert undefined or null to object");
    for (var b = Object(a), c = 1; c < arguments.length; c++) {
      var e = arguments[c];
      if (e !== d && null !== e) for (var f in e) e.hasOwnProperty(f) && (b[f] = e[f]);
    }
    return b;
  } : Object.assign;
  var sa = h(function (a, b, c) {
    for (var e = Object.keys(b), f = 0; f < e.length;) (!c || c && a[e[f]] === d) && (a[e[f]] = b[e[f]]), f++;
    return a;
  }, "extend", "Use `assign`."),
      ta = h(function (a, b) {
    return sa(a, b, !0);
  }, "merge", "Use `assign`."),
      ua = 1,
      va = /mobile|tablet|ip(ad|hone|od)|android/i,
      wa = "ontouchstart" in a,
      xa = u(a, "PointerEvent") !== d,
      ya = wa && va.test(navigator.userAgent),
      za = "touch",
      Aa = "pen",
      Ba = "mouse",
      Ca = "kinect",
      Da = 25,
      Ea = 1,
      Fa = 2,
      Ga = 4,
      Ha = 8,
      Ia = 1,
      Ja = 2,
      Ka = 4,
      La = 8,
      Ma = 16,
      Na = Ja | Ka,
      Oa = La | Ma,
      Pa = Na | Oa,
      Qa = ["x", "y"],
      Ra = ["clientX", "clientY"];
  x.prototype = {
    handler: function () {},
    init: function () {
      this.evEl && m(this.element, this.evEl, this.domHandler), this.evTarget && m(this.target, this.evTarget, this.domHandler), this.evWin && m(w(this.element), this.evWin, this.domHandler);
    },
    destroy: function () {
      this.evEl && n(this.element, this.evEl, this.domHandler), this.evTarget && n(this.target, this.evTarget, this.domHandler), this.evWin && n(w(this.element), this.evWin, this.domHandler);
    }
  };
  var Sa = {
    mousedown: Ea,
    mousemove: Fa,
    mouseup: Ga
  },
      Ta = "mousedown",
      Ua = "mousemove mouseup";
  i(L, x, {
    handler: function (a) {
      var b = Sa[a.type];
      b & Ea && 0 === a.button && (this.pressed = !0), b & Fa && 1 !== a.which && (b = Ga), this.pressed && (b & Ga && (this.pressed = !1), this.callback(this.manager, b, {
        pointers: [a],
        changedPointers: [a],
        pointerType: Ba,
        srcEvent: a
      }));
    }
  });
  var Va = {
    pointerdown: Ea,
    pointermove: Fa,
    pointerup: Ga,
    pointercancel: Ha,
    pointerout: Ha
  },
      Wa = {
    2: za,
    3: Aa,
    4: Ba,
    5: Ca
  },
      Xa = "pointerdown",
      Ya = "pointermove pointerup pointercancel";
  a.MSPointerEvent && !a.PointerEvent && (Xa = "MSPointerDown", Ya = "MSPointerMove MSPointerUp MSPointerCancel"), i(M, x, {
    handler: function (a) {
      var b = this.store,
          c = !1,
          d = a.type.toLowerCase().replace("ms", ""),
          e = Va[d],
          f = Wa[a.pointerType] || a.pointerType,
          g = f == za,
          h = r(b, a.pointerId, "pointerId");
      e & Ea && (0 === a.button || g) ? 0 > h && (b.push(a), h = b.length - 1) : e & (Ga | Ha) && (c = !0), 0 > h || (b[h] = a, this.callback(this.manager, e, {
        pointers: b,
        changedPointers: [a],
        pointerType: f,
        srcEvent: a
      }), c && b.splice(h, 1));
    }
  });
  var Za = {
    touchstart: Ea,
    touchmove: Fa,
    touchend: Ga,
    touchcancel: Ha
  },
      $a = "touchstart",
      _a = "touchstart touchmove touchend touchcancel";
  i(N, x, {
    handler: function (a) {
      var b = Za[a.type];
      if (b === Ea && (this.started = !0), this.started) {
        var c = O.call(this, a, b);
        b & (Ga | Ha) && c[0].length - c[1].length === 0 && (this.started = !1), this.callback(this.manager, b, {
          pointers: c[0],
          changedPointers: c[1],
          pointerType: za,
          srcEvent: a
        });
      }
    }
  });
  var ab = {
    touchstart: Ea,
    touchmove: Fa,
    touchend: Ga,
    touchcancel: Ha
  },
      bb = "touchstart touchmove touchend touchcancel";
  i(P, x, {
    handler: function (a) {
      var b = ab[a.type],
          c = Q.call(this, a, b);
      c && this.callback(this.manager, b, {
        pointers: c[0],
        changedPointers: c[1],
        pointerType: za,
        srcEvent: a
      });
    }
  });
  var cb = 2500,
      db = 25;
  i(R, x, {
    handler: function (a, b, c) {
      var d = c.pointerType == za,
          e = c.pointerType == Ba;
      if (!(e && c.sourceCapabilities && c.sourceCapabilities.firesTouchEvents)) {
        if (d) S.call(this, b, c);else if (e && U.call(this, c)) return;
        this.callback(a, b, c);
      }
    },
    destroy: function () {
      this.touch.destroy(), this.mouse.destroy();
    }
  });
  var eb = u(na.style, "touchAction"),
      fb = eb !== d,
      gb = "compute",
      hb = "auto",
      ib = "manipulation",
      jb = "none",
      kb = "pan-x",
      lb = "pan-y",
      mb = X();
  V.prototype = {
    set: function (a) {
      a == gb && (a = this.compute()), fb && this.manager.element.style && mb[a] && (this.manager.element.style[eb] = a), this.actions = a.toLowerCase().trim();
    },
    update: function () {
      this.set(this.manager.options.touchAction);
    },
    compute: function () {
      var a = [];
      return g(this.manager.recognizers, function (b) {
        k(b.options.enable, [b]) && (a = a.concat(b.getTouchAction()));
      }), W(a.join(" "));
    },
    preventDefaults: function (a) {
      var b = a.srcEvent,
          c = a.offsetDirection;
      if (this.manager.session.prevented) return void b.preventDefault();
      var d = this.actions,
          e = p(d, jb) && !mb[jb],
          f = p(d, lb) && !mb[lb],
          g = p(d, kb) && !mb[kb];
      if (e) {
        var h = 1 === a.pointers.length,
            i = a.distance < 2,
            j = a.deltaTime < 250;
        if (h && i && j) return;
      }
      return g && f ? void 0 : e || f && c & Na || g && c & Oa ? this.preventSrc(b) : void 0;
    },
    preventSrc: function (a) {
      this.manager.session.prevented = !0, a.preventDefault();
    }
  };
  var nb = 1,
      ob = 2,
      pb = 4,
      qb = 8,
      rb = qb,
      sb = 16,
      tb = 32;
  Y.prototype = {
    defaults: {},
    set: function (a) {
      return la(this.options, a), this.manager && this.manager.touchAction.update(), this;
    },
    recognizeWith: function (a) {
      if (f(a, "recognizeWith", this)) return this;
      var b = this.simultaneous;
      return a = _(a, this), b[a.id] || (b[a.id] = a, a.recognizeWith(this)), this;
    },
    dropRecognizeWith: function (a) {
      return f(a, "dropRecognizeWith", this) ? this : (a = _(a, this), delete this.simultaneous[a.id], this);
    },
    requireFailure: function (a) {
      if (f(a, "requireFailure", this)) return this;
      var b = this.requireFail;
      return a = _(a, this), -1 === r(b, a) && (b.push(a), a.requireFailure(this)), this;
    },
    dropRequireFailure: function (a) {
      if (f(a, "dropRequireFailure", this)) return this;
      a = _(a, this);
      var b = r(this.requireFail, a);
      return b > -1 && this.requireFail.splice(b, 1), this;
    },
    hasRequireFailures: function () {
      return this.requireFail.length > 0;
    },
    canRecognizeWith: function (a) {
      return !!this.simultaneous[a.id];
    },
    emit: function (a) {
      function b(b) {
        c.manager.emit(b, a);
      }
      var c = this,
          d = this.state;
      qb > d && b(c.options.event + Z(d)), b(c.options.event), a.additionalEvent && b(a.additionalEvent), d >= qb && b(c.options.event + Z(d));
    },
    tryEmit: function (a) {
      return this.canEmit() ? this.emit(a) : void (this.state = tb);
    },
    canEmit: function () {
      for (var a = 0; a < this.requireFail.length;) {
        if (!(this.requireFail[a].state & (tb | nb))) return !1;
        a++;
      }
      return !0;
    },
    recognize: function (a) {
      var b = la({}, a);
      return k(this.options.enable, [this, b]) ? (this.state & (rb | sb | tb) && (this.state = nb), this.state = this.process(b), void (this.state & (ob | pb | qb | sb) && this.tryEmit(b))) : (this.reset(), void (this.state = tb));
    },
    process: function (a) {},
    getTouchAction: function () {},
    reset: function () {}
  }, i(aa, Y, {
    defaults: {
      pointers: 1
    },
    attrTest: function (a) {
      var b = this.options.pointers;
      return 0 === b || a.pointers.length === b;
    },
    process: function (a) {
      var b = this.state,
          c = a.eventType,
          d = b & (ob | pb),
          e = this.attrTest(a);
      return d && (c & Ha || !e) ? b | sb : d || e ? c & Ga ? b | qb : b & ob ? b | pb : ob : tb;
    }
  }), i(ba, aa, {
    defaults: {
      event: "pan",
      threshold: 10,
      pointers: 1,
      direction: Pa
    },
    getTouchAction: function () {
      var a = this.options.direction,
          b = [];
      return a & Na && b.push(lb), a & Oa && b.push(kb), b;
    },
    directionTest: function (a) {
      var b = this.options,
          c = !0,
          d = a.distance,
          e = a.direction,
          f = a.deltaX,
          g = a.deltaY;
      return e & b.direction || (b.direction & Na ? (e = 0 === f ? Ia : 0 > f ? Ja : Ka, c = f != this.pX, d = Math.abs(a.deltaX)) : (e = 0 === g ? Ia : 0 > g ? La : Ma, c = g != this.pY, d = Math.abs(a.deltaY))), a.direction = e, c && d > b.threshold && e & b.direction;
    },
    attrTest: function (a) {
      return aa.prototype.attrTest.call(this, a) && (this.state & ob || !(this.state & ob) && this.directionTest(a));
    },
    emit: function (a) {
      this.pX = a.deltaX, this.pY = a.deltaY;
      var b = $(a.direction);
      b && (a.additionalEvent = this.options.event + b), this._super.emit.call(this, a);
    }
  }), i(ca, aa, {
    defaults: {
      event: "pinch",
      threshold: 0,
      pointers: 2
    },
    getTouchAction: function () {
      return [jb];
    },
    attrTest: function (a) {
      return this._super.attrTest.call(this, a) && (Math.abs(a.scale - 1) > this.options.threshold || this.state & ob);
    },
    emit: function (a) {
      if (1 !== a.scale) {
        var b = a.scale < 1 ? "in" : "out";
        a.additionalEvent = this.options.event + b;
      }
      this._super.emit.call(this, a);
    }
  }), i(da, Y, {
    defaults: {
      event: "press",
      pointers: 1,
      time: 251,
      threshold: 9
    },
    getTouchAction: function () {
      return [hb];
    },
    process: function (a) {
      var b = this.options,
          c = a.pointers.length === b.pointers,
          d = a.distance < b.threshold,
          f = a.deltaTime > b.time;
      if (this._input = a, !d || !c || a.eventType & (Ga | Ha) && !f) this.reset();else if (a.eventType & Ea) this.reset(), this._timer = e(function () {
        this.state = rb, this.tryEmit();
      }, b.time, this);else if (a.eventType & Ga) return rb;
      return tb;
    },
    reset: function () {
      clearTimeout(this._timer);
    },
    emit: function (a) {
      this.state === rb && (a && a.eventType & Ga ? this.manager.emit(this.options.event + "up", a) : (this._input.timeStamp = ra(), this.manager.emit(this.options.event, this._input)));
    }
  }), i(ea, aa, {
    defaults: {
      event: "rotate",
      threshold: 0,
      pointers: 2
    },
    getTouchAction: function () {
      return [jb];
    },
    attrTest: function (a) {
      return this._super.attrTest.call(this, a) && (Math.abs(a.rotation) > this.options.threshold || this.state & ob);
    }
  }), i(fa, aa, {
    defaults: {
      event: "swipe",
      threshold: 10,
      velocity: .3,
      direction: Na | Oa,
      pointers: 1
    },
    getTouchAction: function () {
      return ba.prototype.getTouchAction.call(this);
    },
    attrTest: function (a) {
      var b,
          c = this.options.direction;
      return c & (Na | Oa) ? b = a.overallVelocity : c & Na ? b = a.overallVelocityX : c & Oa && (b = a.overallVelocityY), this._super.attrTest.call(this, a) && c & a.offsetDirection && a.distance > this.options.threshold && a.maxPointers == this.options.pointers && qa(b) > this.options.velocity && a.eventType & Ga;
    },
    emit: function (a) {
      var b = $(a.offsetDirection);
      b && this.manager.emit(this.options.event + b, a), this.manager.emit(this.options.event, a);
    }
  }), i(ga, Y, {
    defaults: {
      event: "tap",
      pointers: 1,
      taps: 1,
      interval: 300,
      time: 250,
      threshold: 9,
      posThreshold: 10
    },
    getTouchAction: function () {
      return [ib];
    },
    process: function (a) {
      var b = this.options,
          c = a.pointers.length === b.pointers,
          d = a.distance < b.threshold,
          f = a.deltaTime < b.time;
      if (this.reset(), a.eventType & Ea && 0 === this.count) return this.failTimeout();
      if (d && f && c) {
        if (a.eventType != Ga) return this.failTimeout();
        var g = this.pTime ? a.timeStamp - this.pTime < b.interval : !0,
            h = !this.pCenter || H(this.pCenter, a.center) < b.posThreshold;
        this.pTime = a.timeStamp, this.pCenter = a.center, h && g ? this.count += 1 : this.count = 1, this._input = a;
        var i = this.count % b.taps;
        if (0 === i) return this.hasRequireFailures() ? (this._timer = e(function () {
          this.state = rb, this.tryEmit();
        }, b.interval, this), ob) : rb;
      }
      return tb;
    },
    failTimeout: function () {
      return this._timer = e(function () {
        this.state = tb;
      }, this.options.interval, this), tb;
    },
    reset: function () {
      clearTimeout(this._timer);
    },
    emit: function () {
      this.state == rb && (this._input.tapCount = this.count, this.manager.emit(this.options.event, this._input));
    }
  }), ha.VERSION = "2.0.8", ha.defaults = {
    domEvents: !1,
    touchAction: gb,
    enable: !0,
    inputTarget: null,
    inputClass: null,
    preset: [[ea, {
      enable: !1
    }], [ca, {
      enable: !1
    }, ["rotate"]], [fa, {
      direction: Na
    }], [ba, {
      direction: Na
    }, ["swipe"]], [ga], [ga, {
      event: "doubletap",
      taps: 2
    }, ["tap"]], [da]],
    cssProps: {
      userSelect: "none",
      touchSelect: "none",
      touchCallout: "none",
      contentZooming: "none",
      userDrag: "none",
      tapHighlightColor: "rgba(0,0,0,0)"
    }
  };
  var ub = 1,
      vb = 2;
  ia.prototype = {
    set: function (a) {
      return la(this.options, a), a.touchAction && this.touchAction.update(), a.inputTarget && (this.input.destroy(), this.input.target = a.inputTarget, this.input.init()), this;
    },
    stop: function (a) {
      this.session.stopped = a ? vb : ub;
    },
    recognize: function (a) {
      var b = this.session;
      if (!b.stopped) {
        this.touchAction.preventDefaults(a);
        var c,
            d = this.recognizers,
            e = b.curRecognizer;
        (!e || e && e.state & rb) && (e = b.curRecognizer = null);
        for (var f = 0; f < d.length;) c = d[f], b.stopped === vb || e && c != e && !c.canRecognizeWith(e) ? c.reset() : c.recognize(a), !e && c.state & (ob | pb | qb) && (e = b.curRecognizer = c), f++;
      }
    },
    get: function (a) {
      if (a instanceof Y) return a;
      for (var b = this.recognizers, c = 0; c < b.length; c++) if (b[c].options.event == a) return b[c];
      return null;
    },
    add: function (a) {
      if (f(a, "add", this)) return this;
      var b = this.get(a.options.event);
      return b && this.remove(b), this.recognizers.push(a), a.manager = this, this.touchAction.update(), a;
    },
    remove: function (a) {
      if (f(a, "remove", this)) return this;
      if (a = this.get(a)) {
        var b = this.recognizers,
            c = r(b, a);-1 !== c && (b.splice(c, 1), this.touchAction.update());
      }
      return this;
    },
    on: function (a, b) {
      if (a !== d && b !== d) {
        var c = this.handlers;
        return g(q(a), function (a) {
          c[a] = c[a] || [], c[a].push(b);
        }), this;
      }
    },
    off: function (a, b) {
      if (a !== d) {
        var c = this.handlers;
        return g(q(a), function (a) {
          b ? c[a] && c[a].splice(r(c[a], b), 1) : delete c[a];
        }), this;
      }
    },
    emit: function (a, b) {
      this.options.domEvents && ka(a, b);
      var c = this.handlers[a] && this.handlers[a].slice();
      if (c && c.length) {
        b.type = a, b.preventDefault = function () {
          b.srcEvent.preventDefault();
        };
        for (var d = 0; d < c.length;) c[d](b), d++;
      }
    },
    destroy: function () {
      this.element && ja(this, !1), this.handlers = {}, this.session = {}, this.input.destroy(), this.element = null;
    }
  }, la(ha, {
    INPUT_START: Ea,
    INPUT_MOVE: Fa,
    INPUT_END: Ga,
    INPUT_CANCEL: Ha,
    STATE_POSSIBLE: nb,
    STATE_BEGAN: ob,
    STATE_CHANGED: pb,
    STATE_ENDED: qb,
    STATE_RECOGNIZED: rb,
    STATE_CANCELLED: sb,
    STATE_FAILED: tb,
    DIRECTION_NONE: Ia,
    DIRECTION_LEFT: Ja,
    DIRECTION_RIGHT: Ka,
    DIRECTION_UP: La,
    DIRECTION_DOWN: Ma,
    DIRECTION_HORIZONTAL: Na,
    DIRECTION_VERTICAL: Oa,
    DIRECTION_ALL: Pa,
    Manager: ia,
    Input: x,
    TouchAction: V,
    TouchInput: P,
    MouseInput: L,
    PointerEventInput: M,
    TouchMouseInput: R,
    SingleTouchInput: N,
    Recognizer: Y,
    AttrRecognizer: aa,
    Tap: ga,
    Pan: ba,
    Swipe: fa,
    Pinch: ca,
    Rotate: ea,
    Press: da,
    on: m,
    off: n,
    each: g,
    merge: ta,
    extend: sa,
    assign: la,
    inherit: i,
    bindFn: j,
    prefixed: u
  });
  var wb = "undefined" != typeof a ? a : "undefined" != typeof self ? self : {};
  wb.Hammer = ha, "function" == typeof define && define.amd ? define(function () {
    return ha;
  }) : "undefined" != typeof module && module.exports ? module.exports = ha : a[c] = ha;
}(window, document, "Hammer");
//# sourceMappingURL=hammer.min.js.map
;///dropdown for Genre
$(document).ready(function () {

  $('.filterGenre').click(function () {
    $('.filterGenre__icon').toggleClass('iconActive');
    $('.filterGenre__dropdown').toggleClass('dropdownActive');
  });
  /// show icond when checkbox in step 4 is checked
  $('#checkbox-12:checkbox').click(function () {
    $('.coctailRed').toggleClass('showRefreshments');
  });

  $('#checkbox-13:checkbox').click(function () {
    $('.drinkRed').toggleClass('showRefreshments');
  });

  $('#checkbox-14:checkbox').click(function () {
    $('.utensilsRed').toggleClass('showRefreshments');
  });

  //image slider
  $("#myImageSlider").owlCarousel({
    stagePadding: 100,
    loop: true,
    margin: 10,
    nav: false,
    items: 1,
    autoplay: true,
    autoplaySpeed: 1500,
    autoplayTimeout: 10000,
    responsive: {
      300: {
        items: 1,
        stagePadding: 40
      },
      600: {
        items: 1,
        stagePadding: 60
      },
      1000: {
        items: 1,
        stagePadding: 100
      },
      1400: {
        items: 1,
        stagePadding: 140
      },
      1600: {
        items: 1,
        stagePadding: 350
      },
      1800: {
        items: 1,
        stagePadding: 400
      }
    }
  });

  //to trigger next slide by clicking on item in slide.
  //butt how to trigger next and previous??
  // see more on https://owlcarousel2.github.io/OwlCarousel2/docs/api-events.html
  // var owl = $("#myImageSlider");
  // owl.owlCarousel();
  //
  // $('.owl-item').click(function() {
  //     owl.trigger('next.owl.carousel');
  // });

  // $('.owl-item').click(function() {
  //   // With optional speed parameter
  //   // Parameters has to be in square bracket '[]'
  //   owl.trigger('prev.owl.carousel');
  // });


  // open the sponsers modal
  var btnShowSponsers = $('#btnShowSponsers');
  var btnCLoseSponsers = $('#btnCLoseSponsers');
  var sponsorsModal = $('#sponsorsModal');

  btnShowSponsers.click(function () {
    console.log('x');
    sponsorsModal.addClass('scaleUp');
  });

  btnCLoseSponsers.click(function () {
    console.log('x');
    sponsorsModal.removeClass('scaleUp');
  });
});
;var btnAllEvents = $('#btnAllEvents');
var eventFilter = $('#eventFilter');
var listPlus = $('.listPlus');

btnAllEvents.click(function () {
  // console.log('x');
  // console.dir($(this));
  // $(this).toggleClass('activeSidebar');
  eventFilter.toggleClass('accordActive');
  listPlus.toggleClass('listPlusActive');
});
;$(document).ready(function () {
  var nextArrow = $('.nextArrow');
  var prevArrow = $('.prevArrow');
  var nextText = $('.nextText');
  var prevText = $('.prevText');
  var headSlider = $('#dasSlider');
  var decline = $('.pending_decline');
  var pendingItem = $('.eventsection__left__container__list__item');
  var setActiveAfter = $('#setActiveAfter');
  nextArrow.hover(function () {
    prevArrow.css('opacity', 0).css('transition', 'all 100ms ease');
    nextText.css('width', '90px').css('transition', 'all 300ms ease');
  }, function () {
    prevArrow.css('opacity', 1).css('transition', 'all 300ms 100ms ease');
    nextText.css('width', 0).css('transition', 'all 200ms ease');
  });

  prevArrow.hover(function () {
    nextArrow.css('opacity', 0).css('transition', 'all 100ms ease');
    prevText.css('width', '120px').css('transition', 'all 300ms ease');
  }, function () {
    nextArrow.css('opacity', 1).css('transition', 'all 300ms 100ms ease');
    prevText.css('width', 0).css('transition', 'all 200ms ease');
  });

  headSlider.owlCarousel({
    'items': 1,
    'loop': true,
    'smartSpeed': 500
  });

  nextArrow.click(function () {
    // console.log('y');
    headSlider.trigger('next.owl.carousel');
  });

  prevArrow.click(function () {
    headSlider.trigger('prev.owl.carousel');
  });

  var thisDecline = $('#thisDecline');
  thisDecline.click(function () {
    console.log('x');
    console.dir(setActiveAfter);
    setActiveAfter.addClass('selectedEvent');
    $(this)[0].parentNode.parentNode.remove();
  });
});
;function hidePages(pageClass, showClass) {
  var aPages = document.querySelectorAll('.' + pageClass);
  for (var j = 0; j < aPages.length; j++) {
    // console.log(aPages[j].classList);
    aPages[j].classList.remove(showClass);
  }
}

function hideActiveClass(btnClass, navActiveClass) {
  var theBtnClass = document.querySelectorAll('.' + btnClass);
  for (var i = 0; i < theBtnClass.length; i++) {
    theBtnClass[i].classList.remove(navActiveClass);
  }
}

function createNav(pageClass, showClass, btnClass) {
  document.addEventListener('click', function (e) {
    if (e.target.classList.contains(btnClass)) {
      if (btnClass == 'btnCmsNav' || e.target.parentNode.classList.contains('btnCmsNav')) {
        hideActiveClass('btnCmsNav', 'activeSidebar');
        e.target.classList.add('activeSidebar');
      }
      // console.log('p');
      hidePages(pageClass, showClass);

      var pageId = e.target.getAttribute('data-page');
      // console.log(pageId);
      localStorage.pageId = pageId;
      var getPage = document.querySelector('#' + pageId);
      getPage.classList.add(showClass);
      // console.log(pageId);
      if (pageId == 'pageFront') {
        topBar.classList.remove('addShadow');
      } else {
        topBar.classList.add('addShadow');
      }
    }
  });
}

createNav('rootPage', 'showRootPage', 'btnRootNav');
createNav('cmsPage', 'showCmsPage', 'btnCmsNav');
// localStorage.pageId = 'pageFront';

window.onload = function () {
  if (localStorage.getItem("hasCodeRunBefore") === null) {
    localStorage.pageId = 'pageFront';
    topBar.classList.remove('addShadow');
    localStorage.setItem("hasCodeRunBefore", true);
  }
};

// if (!localStorage.hasCodeRunBefore) {
//   localStorage.pageId = 'pageFront';
// }
if (localStorage.pageId == 'pageFront' || localStorage.pageId == undefined) {
  topBar.classList.remove('addShadow');
} else {
  topBar.classList.add('addShadow');
}
switch (localStorage.pageId) {
  case 'pageFront':
    topBar.classList.remove('addShadow');
    break;
  case 'pageEvents':
    topBar.classList.add('addShadow');
    break;
  case 'cmsPage':
    topBar.classList.add('addShadow');
    break;
  default:

}

// console.log(localStorage.pageId);

var cmsBurger = $('#cmsBurger');
var cmsSidebar = $('#cmsSidebar');
cmsBurger.click(function () {
  // console.log('x');
  $(this).toggleClass('burgerActive');
  $('#cmsSidebar').toggleClass('sideBarHidden');
  $('.eventsection__right').toggleClass('eventRightAddjust');
});

var aImgList = ['opt_img/unprosessed_slider_img/techtornado_pic1.jpg', 'opt_img/unprosessed_slider_img/techtornado_pic2.jpg', 'opt_img/unprosessed_slider_img/techtornado_pic3.jpg', 'opt_img/unprosessed_slider_img/techtornado_pic4.jpg', 'opt_img/unprosessed_slider_img/techtornado_pic5.jpg', 'opt_img/unprosessed_slider_img/techtornado_pic6.jpg', 'opt_img/unprosessed_slider_img/techtornado_pic7.jpg', 'opt_img/unprosessed_slider_img/techtornado_pic8.jpg', 'opt_img/unprosessed_slider_img/techtornado_pic9.jpg', 'opt_img/unprosessed_slider_img/techtornado_pic10.jpg'];

function randomNumberFromRange(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}
var randomImgNumber = 0;

function clickedEvent(motherClass, pageId) {
  $('#' + pageId + ' .eventsection__right__event img').attr('src', aImgList[randomNumberFromRange(0, 10)]);
  $('.' + motherClass + ' .eventsection__left__container__list__item').click(function () {
    // console.log('list');
    randomImgNumber = randomNumberFromRange(0, 10);
    $('.' + motherClass + ' .eventsection__left__container__list__item').removeClass('selectedEvent');
    $(this).addClass('selectedEvent');
    var sThisHeading = $(this).children().children('h3').html();
    $('#' + pageId + ' .eventsection__right__event > h2').text(sThisHeading);
    $('#' + pageId + ' .eventsection__right__event img').attr('src', aImgList[randomImgNumber]);
    if (pageId != 'pageEvents' || pageId != 'pagePendingEvents') {
      var views = $('#' + pageId + ' .eventsection__right__stats__item')[0];
      var attending = $('#' + pageId + ' .eventsection__right__stats__item')[1];
      var shares = $('#' + pageId + ' .eventsection__right__stats__item')[2];
      views.children[1].children[0].innerHTML = randomNumberFromRange(0, 1000);
      attending.children[1].children[0].innerHTML = randomNumberFromRange(0, 300);
      shares.children[1].children[0].innerHTML = randomNumberFromRange(0, 300);
      // console.dir(views.children[1].children[0].innerHTML);
    }
  });
}

clickedEvent('fpAllEventsList', 'pageEvents');
clickedEvent('cmsAllEventsList', 'pageAllEvents');
clickedEvent('cmsMyEventsList', 'pageMyEvents');
clickedEvent('cmsPendingList', 'pagePendingEvents');
;$(document).ready(function () {

  $('#btnSubscribebtn').click(function () {
    console.log('x');
    $('.fp-subscribe__btn-subscribe').toggleClass('activeForm');
    $('.fp-subscribe__frmSubscribe').toggleClass('showForm');
  });
});
;$(document).ready(function () {
  // Input Email Icon
  $(".inputLogInEmail").focus(function () {
    $(".envelopeRed").css({
      "transition": "all 300ms 100ms ease",
      "fill": "#FF6565",
      "transform": "translateX(0px)"
    });
    $(".envelopeRedToBlack").css({
      "stroke": "#000"
    });
  });

  // Input password Icon
  $(".inputLogInPassword").focus(function () {
    $(".lockRed").css({
      "transition": "all 300ms 100ms ease",
      "fill": "#FF6565",
      "transform": "translateX(0px)"
    });
    $(".lockRedBlack").css({
      "stroke": "#000"
    });
  });

  // Sign in with Facebook Icon
  $(".withFacebook").mouseover(function () {
    $(".arrowForwRedFacebook").css({
      "transition": "all 300ms 100ms ease",
      "fill": "#FF6565",
      "transform": "translateX(0px)"
    });
    $(".logIn_facebook").css({
      "transform": "translateX(5px)"
    });
  });
  $(".withFacebook").mouseout(function () {
    $(".arrowForwRedFacebook").css({
      "transition": "all 300ms 100ms ease",
      "fill": "transparent",
      "transform": "translateX(-5px)"
    });
    $(".logIn_facebook").css({
      "transform": "translateX(0px)"
    });
  });

  // Sign in with Google Icon
  $(".withGoogle").mouseover(function () {
    $(".arrowForwRedGoogle").css({
      "transition": "all 300ms 100ms ease",
      "fill": "#FF6565",
      "transform": "translateX(0px)"
    });
    $(".logIn_google").css({
      "transform": "translateX(5px)"
    });
  });
  $(".withGoogle").mouseout(function () {
    $(".arrowForwRedGoogle").css({
      "transition": "all 300ms 100ms ease",
      "fill": "transparent",
      "transform": "translateX(-10px)"
    });
    $(".logIn_google").css({
      "transform": "translateX(0px)"
    });
  });

  // signin with jquery
  var btnSignin = $('#btnSignin');
  var signIn = $('.signIn');
  var btnCLoseSignIn = $('#btnCLoseSignIn');
  var btnSendSignIn = $('#btnSendSignIn');
  var btnUserOptions = $('#btnUserOptions');
  var userOptionsDropdown = $('#userOptionsDropdown');
  var btnSignOut = $('#signOut');
  var btnCreateevent = $('#btnCreateevent');
  btnSignin.click(function () {
    //console.log('x');
    signIn.addClass('scaleUp');
  });

  btnCreateevent.click(function () {
    //console.log('x');
    signIn.addClass('scaleUp');
  });

  btnCLoseSignIn.click(function () {
    //console.log('x');
    signIn.removeClass('scaleUp');
  });

  btnSendSignIn.click(function () {
    $.post('api-signin.php', {
      'loggedin': true
    }).done(function (data) {
      console.log(data);
      signIn.removeClass('scaleUp');
      hidePages('rootPage', 'showRootPage');
      pageCms.classList.add('showRootPage');
      localStorage.pageId = 'pageCms';
      window.location.replace('index.php');
    });
  });

  btnUserOptions.click(function () {
    // console.log('x');
    userOptionsDropdown.toggleClass('dropDownActive');
  });

  $(document).mouseup(function (e) {
    var container = btnUserOptions;

    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0) {
      userOptionsDropdown.removeClass('dropDownActive');
    }
  });

  btnSignOut.click(function () {
    // console.log('x');
    $.get('api-loggout.php?logout=true', function () {
      hidePages('rootPage', 'showRootPage');
      pageFront.classList.add('showRootPage');
      localStorage.pageId = 'pageFront';
      window.location.replace('index.php');
    });
  });
});

$('.loader').delay(1500).fadeOut('fast');

// var closeButton = document.querySelector(".signIn__close");
// var divLogIn = document.querySelector(".signIn");
// closeButton.addEventListener("click", function() {
//   divLogIn.style.display = "none";
// });
//
// var logInFacebook = document.querySelector(".withFacebook");
// var logInGoogle = document.querySelector(".withGoogle");
;$(document).ready(function () {

  $("#fromOnetoTwo").click(function () {
    $(".step1").css("display", "none");
    $(".step2").css("display", "block");
    $(".step3").css("display", "none");
    $(".step4").css("display", "none");
    $(".stepDone").css("display", "none");
    $(".step2__line").addClass("step2-line");
  });
  $("#fromTwotoOne").click(function () {
    $(".step1").css("display", "block");
    $(".step2").css("display", "none");
    $(".step3").css("display", "none");
    $(".step4").css("display", "none");
    $(".stepDone").css("display", "none");
    // $(".placement-line").addClass("placement-line-two");
    // $(".placement-line").removeClass("placement-line-two2one");
    // $(".input-form__step-two").css("background-color", "#E7FCF9");
  });
  $("#fromTwotoThree").click(function () {
    $(".step1").css("display", "none");
    $(".step2").css("display", "none");
    $(".step3").css("display", "block");
    $(".step4").css("display", "none");
    $(".stepDone").css("display", "none");
    $(".step3__line").addClass("step3-line");
    // $(".placement-line").removeClass("placement-line-two2one");
    // $(".input-form__step-two").css("background-color", "#E7FCF9");
  });
  $("#fromThreetoTwo").click(function () {
    $(".step1").css("display", "none");
    $(".step2").css("display", "block");
    $(".step3").css("display", "none");
    $(".step4").css("display", "none");
    $(".stepDone").css("display", "none");
    // $(".placement-line").addClass("placement-line-two");
    // $(".placement-line").removeClass("placement-line-two2one");
    // $(".input-form__step-two").css("background-color", "#E7FCF9");
  });
  $("#fromThreetoFour").click(function () {
    $(".step1").css("display", "none");
    $(".step2").css("display", "none");
    $(".step3").css("display", "none");
    $(".step4").css("display", "block");
    $(".stepDone").css("display", "none");
    $(".step4__line").addClass("step4-line");
    // $(".placement-line").addClass("placement-line-two");
    // $(".placement-line").removeClass("placement-line-two2one");
    // $(".input-form__step-two").css("background-color", "#E7FCF9");
  });
  $("#fromFourtoThree").click(function () {
    $(".step1").css("display", "none");
    $(".step2").css("display", "none");
    $(".step3").css("display", "block");
    $(".step4").css("display", "none");
    $(".stepDone").css("display", "none");
    // $(".placement-line").addClass("placement-line-two");
    // $(".placement-line").removeClass("placement-line-two2one");
    // $(".input-form__step-two").css("background-color", "#E7FCF9");
  });
  $("#fromFourtoDone").click(function () {
    $(".step1").css("display", "none");
    $(".step2").css("display", "none");
    $(".step3").css("display", "none");
    $(".step4").css("display", "none");
    $(".stepDone").css("display", "block");
    $(".stepDone__line").addClass("stepDone-line");
    // $(".placement-line").addClass("placement-line-two");
    // $(".placement-line").removeClass("placement-line-two2one");
    // $(".input-form__step-two").css("background-color", "#E7FCF9");
  });

  /***** * * * CREATE EVENT * * * *****/
  //EVENT NAME
  $(".inputCreateEventName").focus(function () {
    $(".tagRedFill").css({
      "transition": "all 300ms 100ms ease",
      "fill": "#FF6565",
      "transform": "translate(-6px, 5px)"
    });
    $(".tagFill").css({
      "fill": "#000"
    });
  });
  //LOCATION
  $(".inputCreateEventLocation").focus(function () {
    $(".locationRedFill").css({
      "transition": "all 300ms 100ms ease",
      "fill": "#FF6565",
      "transform": "translate(-2px, -1px)"
    });
    $(".locationRedStroke").css({
      "stroke": "#000"
    });
  });
  //CLOCK
  $(".inputCreateEventClock").focus(function () {
    console.log("Event");
    $(".clockRedFill").css({
      "transition": "all 300ms 100ms ease",
      "fill": "#FF6565",
      "transform": "translateX(0px)"
    });
    $(".clockRedStroke").css({
      "stroke": "#000"
    });
  });
  //PRICE
  $(".inputCreateEventPrice").focus(function () {
    $(".priceRedFill").css({
      "transition": "all 300ms 100ms ease",
      "stroke": "#FF6565",
      "transform": "translateX(0px)"
    });
    $(".priceRedStroke").css({
      "stroke": "#000",
      "fill": "#000"
    });
  });
});
;var isMobile = false;
if ($(window).innerWidth() < 769) {
  isMobile = true;
}
console.log(isMobile);

if (isMobile) {
  var pageEvents = document.querySelector('#pageEvents');
  if (pageEvents) {
    var hammertime = new Hammer(pageEvents);
    hammertime.on('swipe', function (ev) {
      // console.dir(eventLeftCmsAll);
      eventLeft.classList.toggle('resizeLeft');
      filterBackground.classList.toggle('rezizeFilter');
      eventRight.classList.toggle('swipeRight');
    });
    hammertime.get('swipe').set({
      direction: Hammer.DIRECTION_HORIZONTAL
    });
  }

  var pageAllEvents = document.querySelector('#pageAllEvents');
  if (pageAllEvents) {
    var hammertimeAll = new Hammer(pageAllEvents);
    hammertimeAll.on('pan', function (ev) {
      console.log($('.eventsection__left').width());

      eventLeftCmsAll.classList.toggle('resizeLeft');
      filterBackgroundAll.classList.toggle('rezizeFilter');
      eventRightAll.classList.toggle('swipeRight');
    });

    // hammertimeAll.get('swipe').set({
    //   direction: Hammer.DIRECTION_HORIZONTAL
    // });
  }

  var pagePendingEvents = document.querySelector('#pagePendingEvents');
  if (pagePendingEvents) {
    var hammertimePending = new Hammer(pagePendingEvents);
    hammertimePending.on('swipe', function (ev) {
      // console.dir('x');
      eventLeftcmsPending.classList.toggle('resizeLeft');
      filterBackgroundPending.classList.toggle('rezizeFilter');
      eventRightPending.classList.toggle('swipeRight');
    });
  }

  var pageMyEvents = document.querySelector('#pageMyEvents');
  if (pageMyEvents) {
    var hammertimeMyEvents = new Hammer(pageMyEvents);
    hammertimeMyEvents.on('swipe', function (ev) {
      console.dir('x');
      eventLeftcmsMyEvents.classList.toggle('resizeLeft');
      filterBackgroundMyEvents.classList.toggle('rezizeFilter');
      eventRightMyEvents.classList.toggle('swipeRight');
    });
  }
}
// console.log(pagePendingEvents);
//# sourceMappingURL=scripts.js.map
