<div class="loader">
  <div class="myTornado">
    <span class="firstLine"></span>
    <span class="secondLine"></span>
    <span class="thirdLine"></span>
    <span class="fourthLine"></span>
    <span class="fifthLine"></span>
  </div>
</div>
