<?php
  session_start();
  $_SESSION['loggedin'] = $_POST['loggedin'];
  // echo $_POST['loggedin'];
  ?>
