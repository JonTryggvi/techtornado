<div class="imagesliderContainer">
  <div id="myImageSlider" class="imagesliderContainer__allItems owl-carousel">
    <div class="imagesliderContainer__allItems__oneItem">
      <img src="img/unprosessed_slider_img/techtornado_pic1.jpg" alt="" />
      <p>From exhibition at Kødbyen hosted by Jarlgaard</p>
    </div>
    <div class="imagesliderContainer__allItems__oneItem">
      <img src="img/unprosessed_slider_img/techtornado_pic2.jpg" alt="" />
      <p>Independent community gatherings.</p>
    </div>
    <div class="imagesliderContainer__allItems__oneItem">
      <img src="img/unprosessed_slider_img/techtornado_pic3.jpg" alt="" />
      <p>Cooperation needs awareness</p>
    </div>
    <div class="imagesliderContainer__allItems__oneItem">
        <img src="img/unprosessed_slider_img/techtornado_pic4.jpg" alt="" />
        <p>Day program all over town</p>
    </div>
    <div class="imagesliderContainer__allItems__oneItem">
      <img src="img/unprosessed_slider_img/techtornado_pic5.jpg" alt="" />
      <p>Happiness at Work with Kjerulf</p>
    </div>
    <div class="imagesliderContainer__allItems__oneItem">
      <img src="img/unprosessed_slider_img/techtornado_pic6.jpg" alt="" />
      <p>What will the future create?</p>
    </div>
    <div class="imagesliderContainer__allItems__oneItem">
      <img src="img/unprosessed_slider_img/techtornado_pic7.jpg" alt="" />
      <p>Khora Virtual Reality </p>
    </div>
    <div class="imagesliderContainer__allItems__oneItem">
      <img src="img/unprosessed_slider_img/techtornado_pic8.jpg" alt="" />
      <p>MANIFEST! by Enigma Museum</p>
    </div>
    <div class="imagesliderContainer__allItems__oneItem">
      <img src="img/unprosessed_slider_img/techtornado_pic9.jpg" alt="" />
      <p>The Glass Room</p>
    </div>
    <div class="imagesliderContainer__allItems__oneItem">
      <img src="img/unprosessed_slider_img/techtornado_pic10.jpg" alt="" />
      <p>What makes a happy workplace?</p>
    </div>
  </div>
</div>
