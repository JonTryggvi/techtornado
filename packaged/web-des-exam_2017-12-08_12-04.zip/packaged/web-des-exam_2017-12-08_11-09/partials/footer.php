<div class="footer_sections">
  <section class="footer">
    <section class="footer-left">

      <div class="myTornado">
        <span class="firstLine"></span>
        <span class="secondLine"></span>
        <span class="thirdLine"></span>
        <span class="fourthLine"></span>
        <span class="fifthLine"></span>
      </div>


    </section>

    <section class="footer-main">
      <div class="footer-main__about">
        <div class="footer-main__about__header">
          <h2>Who's Tech Tornado?</h2>
        </div>
        <div class="footer-main__about__body">
          <div class="footer-main__about__body__txt">
            <p>My money's in that office, right? If she start giving me some bullshit about it ain't there, and we got to go someplace else and get it, I'm gonna shoot you in the head then and there. Then I'm gonna shoot that bitch in the kneecaps, find out where my goddamn money is. She gonna tell me too. Then I'm gonna shoot that bitch in the kneecaps.</p>
          </div>
          <div class="footer-main__about__body__SoMe">
            <div class="footer-main__about__body__SoMe__toMedia">
              <a href="" class="emailUs">Email Us!
                <svg id="arrowForwRed" class="goTo_email" viewBox="0 0 55 41" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" >
                  <polygon id="Fill-41" fill="#FF6565" points="29.3808877 0.727521992 48.0639233 19.3900503 29.3808877 38.0518097" class="arrowForwRed_email"></polygon>
                  <path d="M0.31740411,19.3897427 L52.499489,19.3897427" id="Stroke-42" stroke="#3E3E3E" stroke-width="3"></path>
                  <polyline id="Stroke-43" stroke="#3E3E3E" stroke-width="3" points="34.0046079 0.727521992 52.6876436 19.3900503 34.0046079 38.0518097"></polyline>
                </svg>
              </a>
              <a href="" class="facebookUs">Facebook
                <svg id="arrowForwRed" class="goTo_facebook" viewBox="0 0 55 41" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" >
                  <polygon id="Fill-41" fill="#FF6565" points="29.3808877 0.727521992 48.0639233 19.3900503 29.3808877 38.0518097" class="arrowForwRed_facebook"></polygon>
                  <path d="M0.31740411,19.3897427 L52.499489,19.3897427" id="Stroke-42" stroke="#3E3E3E" stroke-width="3"></path>
                  <polyline id="Stroke-43" stroke="#3E3E3E" stroke-width="3" points="34.0046079 0.727521992 52.6876436 19.3900503 34.0046079 38.0518097"></polyline>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="footer-right">
      <div class="footer-right__btn-sponsors">
        <div class="footer-right__btn-sponsors__toSponsers">
          <div href="#" class="ourSponsers">
            <h3>Sponsors</h3>
            <svg id="arrowForwRed" class="goTo_sponsers" viewBox="0 0 55 41" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" >
              <polygon id="Fill-41" fill="#FF6565" points="29.3808877 0.727521992 48.0639233 19.3900503 29.3808877 38.0518097" class="arrowForwRed_sponsers"></polygon>
              <path d="M0.31740411,19.3897427 L52.499489,19.3897427" id="Stroke-42" stroke="#3E3E3E" stroke-width="3"></path>
              <polyline id="Stroke-43" stroke="#3E3E3E" stroke-width="3" points="34.0046079 0.727521992 52.6876436 19.3900503 34.0046079 38.0518097"></polyline>
            </svg>
          </div>
        </div>
      </div>
      <div class="footer-right__box-sponsors">

          <div id="btnShowSponsers" class="btnFloatingForm btnFloatingForm_sponsers">
            <div class="btnFloatingForm__button">
          		<div class="btnFloater btnFloater--style-2" data-animation-path-duration="1500" data-animation-path-easing="easeOutElastic" data-morph-path="M 418.1,159.8 C 460.9,222.9 497,321.5 452.4,383.4 417.2,432.4 371.2,405.6 271.3,420.3 137.2,440 90.45,500.6 42.16,442.8 -9.572,381 86.33,289.1 117.7,215.5 144.3,153.4 145.7,54.21 212.7,36.25 290.3,15.36 373.9,94.6 418.1,159.8 Z" data-path-scaleY="1.1" data-image-scaleX="1.3" data-image-scaleY="1.3" data-animation-deco-duration="2000" data-animation-deco-delay="100" data-deco-rotate="-10">
          			<svg class="btnFloater__svg" width="500px" height="500px" viewBox="0 0 500 500">
          				<clipPath id="clipShape4">
          					<path class="btnFloater__clippath" d="M 378.1,121.2 C 408.4,150 417.2,197.9 411,245.8 404.8,293.7 383.5,341.7 353.4,370.7 303.2,419.1 198.7,427.7 144.5,383.8 86.18,336.5 67.13,221.3 111.9,161 138.6,125 188.9,99.62 240.7,90.92 292.4,82.24 345.6,90.32 378.1,121.2 Z" />
          				</clipPath>
          				<g clip-path="url(#clipShape4)">
          					<image class="btnFloater__img btnFloater__color" xlink:href="img/3.png" x="0" y="0" height="500px" width="500px" />
          				</g>
          			</svg>
          			<div class="btnFloater__meta">
          				<div class="btnFloater__title">
                    <svg class="footer-right__box-sponsors__diamond"><use href="#diamond"></use></svg>
                  </div>
          			</div>
          		</div>
            </div>
          </div>



      </div>
    </section>
  </section>
  <div class="copyright"><p>COPYRIGHT © Tech Tornado. Guldbergsgade 24, 1234 Copenhagen, Denmark</p></div>
</div>
