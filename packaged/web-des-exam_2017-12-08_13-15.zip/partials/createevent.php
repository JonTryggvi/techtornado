<section class="fp-createevent">
    <div id="btnCreateevent" class="fp-createevent__btn-create">
      <span>Create Event</span>
      <!-- arrow_frw_red -->
      <svg id="arrowForwRed" viewBox="0 0 55 41" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" class="fp-createevent__btn-create__arrow leftTrans">
        <polygon id="Fill-41" fill="#FF6565" points="29.3808877 0.727521992 48.0639233 19.3900503 29.3808877 38.0518097" class="redPoly"></polygon>
        <path d="M0.31740411,19.3897427 L52.499489,19.3897427" id="Stroke-42" stroke="#3E3E3E" stroke-width="3"></path>
        <polyline id="Stroke-43" stroke="#3E3E3E" stroke-width="3" points="34.0046079 0.727521992 52.6876436 19.3900503 34.0046079 38.0518097"></polyline>
      </svg>
    </div>
</section>
