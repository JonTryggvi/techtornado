<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Sponsers</title>
    <link rel="stylesheet" href="css/styles.css">

  </head>
  <body>
    <section class="sponsorsModal" id="sponsorsModal">
      <div class="sponsorsModal__btnClose">
          <img src="img/icons/svg/close.svg" alt="">
      </div>
      <div class="sponsorsModal__topInfo">
        <img src="img/icons/svg/diamond.svg" alt="">
        <h2>Our wonderful sponsers!</h2>
        <p>My money's in that office, right? If she start giving me some bullshit about it ain't there, and we got to go someplace else and get it, I'm gonna shoot you in the head then and there. We got to go someplace.</p>
      </div>
      <div class="sponsorsModal__allIcons">
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s1.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s2.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s3.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s4.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s5.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s6.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s7.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s8.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s9.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s10.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s11.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s12.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s13.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s14.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s15.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s16.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s17.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s18.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s19.png" alt="">
        </div>
        <div class="sponsorsModal__allIcons__eachIcon">
          <img src="img/sponsor_logos/s20.png" alt="">
        </div>

      </div>
    </section>
  </body>
</html>
